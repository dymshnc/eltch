'''
:authors: dymshnc.
:license: Apache License, Version 2.0, see LICENSE file.

:copyright: (c) 2022 by dymshnc.
'''

from .eltch import EWheel

__author__ = 'dymshnc'
__version__ = '0.9'
__email__ = 'officialdyomshin@gmail.com'
